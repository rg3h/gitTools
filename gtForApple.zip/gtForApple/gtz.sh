#!/usr/bin/zsh
# gta.sh -- gitTools for Apple -- forces gt.sh to run with the zsh
/usr/bin/zsh ./gt.sh $@
